package webbydebby;

import java.util.List;

import javax.swing.JFrame;

import webbydebby.valgdialog.SwingSketchDialog;
import webbydebby.storagetool.LagringsplassDefinisjon;
import webbydebby.storagetool.LagringsplassStoragetool;

public class Grensesnitt {
	
	public Grensesnitt(){
		LagringsplassDefinisjon storage = new LagringsplassStoragetool();
		storage.init("sketches-3");
		List<String> filenames = storage.getFilenames();
		String sketchName = new SwingSketchDialog().valgListe(filenames);
		boolean isExistingSketch = filenames.contains(sketchName);
		storage.setSketchname(sketchName);
		System.out.println("Sketchnavn: " + sketchName + " Eksisterende?: " + isExistingSketch);
		JFrame jframe = new JFrame();
		new HovedVindu(sketchName, isExistingSketch, storage, jframe);
	}

}
