package webbydebby.storagetool;

import java.io.InputStream;
import java.util.List;

public interface LagringsplassDefinisjon {
	void init(String teamcontainer);
	void upload(InputStream data);
	void setSketchname(String sketchName);
	InputStream download();
	List<String> getFilenames();
}