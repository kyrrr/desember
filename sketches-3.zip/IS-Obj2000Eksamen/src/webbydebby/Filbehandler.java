package webbydebby;

import java.awt.Color;
import java.awt.Point;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import javax.swing.JFrame;

import webbydebby.valgdialog.ListeMedLagredeFiler;
import webbydebby.valgdialog.KonsollInputDialog;
import webbydebby.storagetool.LagringsplassDefinisjon;

public class Filbehandler {
	
	private String sketchName;
	private List<Point> p;
	private List<Color> c;
	private List<Integer> v;
	private LagringsplassDefinisjon storage;
	private JFrame jframe;
	public Filbehandler(String path, LagringsplassDefinisjon storage, JFrame jframe){
		this.storage = storage;
		sketchName = path;
		this.jframe = jframe;
	}
	
	public void setPath(String s){
		sketchName = s;
		jframe.setTitle(s);
	}

	public void tempLists1 (List<Point> tempList1){
		p = tempList1;
	}
	public void tempLists2 (List<Color> tempList2){
		c = tempList2;
	}
	public void tempLists3 (List<Integer> tempList3){
		v = tempList3;
	}
	
	//Lagrer til valgt "pathname"
	public void saveLists(){
		try {	
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(buffer);
			oos.writeObject(p);
			oos.writeObject(c);
			oos.writeObject(v);
			oos.flush();
			oos.close();
			buffer.close();
			InputStream in = new ByteArrayInputStream(buffer.toByteArray());	
			storage.upload(in);
			System.out.println("Lagret");
		} catch (Exception ex) {
			System.out.println("Feil ved skriving av vektor");
			ex.printStackTrace();
		}
	}

//Returnerer en liste over alle punktene i angitt fil
	public void loadLists(){
		try {
			storage.setSketchname(sketchName);
			ObjectInputStream data = new ObjectInputStream(storage.download());
			p = (List<Point>) data.readObject();
			c = (List<Color>) data.readObject();
			v = (List<Integer>) data.readObject();
			Tegneprogram.displayListe = p;
			Tegneprogram.fargeListe = c;
			Tegneprogram.verktoyListe = v;	
			data.close();
		} catch (Exception ex) {
			System.out.println("Feil ved lesing av vektor");
		}
    }

    //forandrer hvilken fil som er aktiv, dvs forandrer pathname til valgt fil
	public void newPath(){
		ListeMedLagredeFiler choose = new KonsollInputDialog(System.in);
		List<String> filenames = storage.getFilenames();
		sketchName = choose.valgListe(filenames);
		boolean isExistingSketch = filenames.contains(sketchName);
		storage.setSketchname(sketchName);
		System.out.println("Sketchnavn: " + sketchName + " Eksisterende?: " + isExistingSketch);
		jframe.setTitle(sketchName);

	}

}
