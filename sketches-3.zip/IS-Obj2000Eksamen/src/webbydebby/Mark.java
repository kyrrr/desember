package webbydebby;

import java.awt.*;
import java.util.*;

/**
 * Created by Odin on 12/11/2015.
 */
public class Mark extends Thread {
    Thread mark = Thread.currentThread();
    Point oldpos, pos;
    Tegneprogram panel;
    static volatile Boolean fortsett=true;
    private Color markfarge=Tegneprogram.farge;

    public Mark(Tegneprogram p, int x,int y){
        panel = p;
        pos = new Point(x,y);
        oldpos = (Point)pos.clone();
    }

    public void run() {
        if (fortsett!=true){
            mark=null;
        }
        while (fortsett) {
            try{sleep(200);}
            catch(InterruptedException e) {fortsett = false;}
            Graphics g = panel.getGraphics();
            int n=0;
            if (g!=null) {
                Rectangle r = panel.getBounds();
                r.x = 2;
                r.y = 2;
                Random rng = new Random();
                if ((r.width*r.height)!=0) {
                    Point nytt;
                    do {
                        nytt = (Point) pos.clone();
                        nytt.x += rng.nextInt(7) - 3;
                        nytt.y += rng.nextInt(7) - 3;
                        n++;
                        if (n>500) nytt = new Point(150,150);
                    }while (!r.contains(nytt));
                    pos = (Point) nytt.clone();
                    g.setColor(markfarge);
                    g.drawLine(oldpos.x,oldpos.y,pos.x,pos.y);
                    SynkronisererLister();
                    g.dispose();
                    oldpos = (Point) pos.clone();
                }
            }
        }
    }

    private synchronized void SynkronisererLister() {
        Tegneprogram.displayListe.add(oldpos);
        Tegneprogram.displayListe.add(pos);
        Tegneprogram.fargeListe.add(markfarge);
        Tegneprogram.fargeListe.add(markfarge);
        Tegneprogram.verktoyListe.add(1);
        Tegneprogram.verktoyListe.add(1);
    }

}
