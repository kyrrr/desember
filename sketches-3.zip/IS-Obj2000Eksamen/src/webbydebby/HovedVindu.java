package webbydebby;

import java.awt.*;

import javax.swing.*;

import webbydebby.storagetool.LagringsplassDefinisjon;

public class HovedVindu /*extends JFrame*/{
	//får inn jframe i stedet for å være en jframe
	private LagringsplassDefinisjon storage;
	private JFrame jframe;

	public HovedVindu(String sketchName, Boolean loaded, LagringsplassDefinisjon storage, JFrame jframe) {
		this.jframe=jframe;
		this.storage = storage;
		startUI(sketchName, loaded);
	}

	private void startUI(String sketchName, Boolean loaded) {
		jframe.setTitle(sketchName);
		jframe.setSize(800, 700);
		jframe.setBackground(Color.black);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Tegneprogram draw = new Tegneprogram(sketchName, loaded, storage, jframe);
		JPanel meny = new JPanel();
		meny.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		KnappeBoks kb = new KnappeBoks();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 0;
		meny.add(kb, gbc);
		JPanel panel = new JPanel();
		panel.setSize(400, 300);
		panel.setVisible(true);
		Fargevelger cp = new Fargevelger(panel);
		panel.add(cp, BorderLayout.SOUTH);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		meny.add(panel, gbc);
		jframe.add(draw, BorderLayout.CENTER);
		jframe.add(meny,BorderLayout.WEST);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		jframe.setLocation(dim.width/2-jframe.getSize().width/2, dim.height/2-jframe.getSize().height/2);
		jframe.setVisible(true);
	}

}
