/**
 * Created by Odin on 11/18/2015.
 */
package webbydebby;

import javax.swing.*;
import java.awt.*;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

class Fargevelger extends JPanel implements AdjustmentListener, ActionListener {

	private int scrollVerdi1;
	private int scrollVerdi2;
	private int scrollVerdi3;
	Scrollbar scr = new Scrollbar(Scrollbar.HORIZONTAL,0,0,0,255 );
	Scrollbar scg = new Scrollbar(Scrollbar.HORIZONTAL,0,0,0,255 );
	Scrollbar scb = new Scrollbar(Scrollbar.HORIZONTAL,0,0,0,255 );
	JPanel c = null;
	JButton Tilfeldig = new JButton("Tilfeldig");

	public Fargevelger(JPanel ic) {
		c = ic;
		c.setBackground(Color.BLACK);
		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		scr.setBackground(Color.WHITE);
		gbc.gridwidth = 3;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 1;
		gbc.gridy = 0;
		add(scr,gbc);
		scg.setBackground(Color.WHITE);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 1;
		gbc.gridy = 1;
		add(scg,gbc);
		scb.setBackground(Color.WHITE);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 1;
		gbc.gridy = 2;
		add(scb,gbc);
		scr.addAdjustmentListener(this);
		scg.addAdjustmentListener(this);
		scb.addAdjustmentListener(this);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridwidth = 3;
		gbc.gridx = 0;
		gbc.gridy = 3;
		add(Tilfeldig,gbc);
		Tilfeldig.addActionListener(this);
	}

	public void adjustmentValueChanged(AdjustmentEvent a) {
		c.setBackground(new Color(scr.getValue(),scg.getValue(),scb.getValue()));
		Tegneprogram.farge=new Color(scr.getValue(),scg.getValue(),scb.getValue());
		Tegneprogram.tegnet=0;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == Tilfeldig) {
			Random r = new Random();
			Tegneprogram.farge=new Color(scrollVerdi1=r.nextInt(256), scrollVerdi2=r.nextInt(256), scrollVerdi3=r.nextInt(256));
			c.setBackground(Tegneprogram.farge);
			Tegneprogram.tegnet=0;
			scr.setValue(scrollVerdi1);
			scg.setValue(scrollVerdi2);
			scb.setValue(scrollVerdi3);
		}
	}

}