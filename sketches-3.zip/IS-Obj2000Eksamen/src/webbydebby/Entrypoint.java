package webbydebby;

public class Entrypoint {

	public static void main(String[] args) {
		new Grensesnitt();
	}

}
