package webbydebby;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import webbydebby.storagetool.LagringsplassDefinisjon;
import org.apache.commons.lang3.time.StopWatch;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class Tegneprogram extends JPanel implements MouseMotionListener, MouseListener, ActionListener, Serializable, Cloneable{

	static List<Point> displayListe = new ArrayList<>();
	static List<Color> fargeListe = new ArrayList<>();
	static List<Integer> verktoyListe = new ArrayList<>();
	JButton clearBtn = new JButton("Tøm");
	JButton refreshBtn = new JButton("Oppdater");
	JButton loadBtn = new JButton("Åpne");
	JButton quitBtn = new JButton("Avslutt");
	Point start = null;
	Point slutt = null;
	StopWatch sw = new StopWatch();
	Boolean changed = false;
	Filbehandler fb;
	private JFrame mainframe;
	static int tegnet = 0;
	static int verktoy = 1;
	static Color farge = Color.BLACK;
	boolean loaded;
	static int maksAntallKanter=100;
	static boolean sjekker;

	public Tegneprogram(String sketchName, Boolean loaded, LagringsplassDefinisjon storage, JFrame mainframe) {
		this.mainframe = mainframe;
		addMouseMotionListener(this);
		addMouseListener(this);
		this.loaded = loaded;
		sw.start();
		fb= new Filbehandler(sketchName, storage, mainframe);
		setLayout(new BorderLayout());
		Panel pan = new Panel();
		clearBtn.addActionListener(this);
		pan.add(clearBtn);
		refreshBtn.addActionListener(this);
		pan.add(refreshBtn);
		loadBtn.addActionListener(this);
		pan.add(loadBtn);
		quitBtn.addActionListener(this);
		pan.add(quitBtn);
		add("North", pan);
		setSize(350, 200);
		Thread a = new Thread(() -> {
			try {
				saveTimer(sw);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		a.start();
	}

	public void mouseDragged(MouseEvent me) {
		if (verktoy == 1 || verktoy == 2 || verktoy ==3 || verktoy == 4) {
			changed = true;
			start = slutt;
			slutt = new Point(me.getX(), me.getY());
			if (start != null && displayListe != null) {
				displayListe.add(start);
				fargeListe.add(farge);
				verktoyListe.add(verktoy);
			}
			else {
				displayListe.add(slutt);
				fargeListe.add(farge);
				verktoyListe.add(verktoy);
			}
			if (verktoy == 1) {
				displayListe.add(slutt);
				fargeListe.add(farge);
				verktoyListe.add(verktoy);
			}
			repaint();
		}
	}

	public void mouseMoved(MouseEvent me) {
		slutt = null;
	}

	public void paint(Graphics g) {

		Point p0;
		Point p1;
		int width;
		int height;
		if (tegnet == 0) {
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, this.getSize().width, getSize().height);
		}
		while (tegnet < fargeListe.size() && tegnet < verktoyListe.size()) {
			g.setColor(fargeListe.get(tegnet));
			farge=fargeListe.get(tegnet);
			verktoy = (verktoyListe.get(tegnet));
			try{
				switch (verktoy) {
				case 1:
					if (tegnet < displayListe.size()-1){
						p0 = displayListe.get(tegnet++);
						p1 = displayListe.get(tegnet++);
						g.drawLine(p0.x, p0.y, p1.x, p1.y);
					}
					else  {
						tegnet++;
					}
					break;
				case 2:
					g.setColor(Color.WHITE);
					p0 = displayListe.get(tegnet++);
					g.fillRect(p0.x-16, p0.y-16, 32, 32);
					break;
				case 3:
					p0 = displayListe.get(tegnet++);
					g.fillRect(p0.x-25, p0.y-25, 50, 50);
					break;
				case 4:
					p0 = displayListe.get(tegnet++);
					g.drawRect(p0.x, p0.y, 100, 100);
					break;
				case 5:
					p0 = displayListe.get(tegnet++);
					p1 = displayListe.get(tegnet++);
					width = p1.x - p0.x;
					height = p1.y - p0.y;
					if (width < 0){
						p0.x=p0.x+width;
						width = Math.abs(width);
					}
					if (height < 0){
						p0.y=p0.y+height;
						height = Math.abs(height);
					}

					g.fillOval(p0.x, p0.y, width, height);
					break;
				case 6:
					p0 = displayListe.get(tegnet++);
					p1 = displayListe.get(tegnet++);
					width = p1.x - p0.x;
					height = p1.y - p0.y;
					if (width < 0) {
						p0.x = p0.x + width;
						width = Math.abs(width);
					}
					if (height < 0) {
						p0.y = p0.y + height;
						height = Math.abs(height);
					}
					g.drawOval(p0.x, p0.y, width, height);
					break;
				case 7:
					int i = 0;
					int xpoints[] = new int[maksAntallKanter];
					int ypoints[] = new int[maksAntallKanter];
					maksAntallKanter=100;
					do {
						p0 = displayListe.get(tegnet++);
						xpoints[i] = p0.x;
						ypoints[i] = p0.y;
						i++;
					}while(tegnet < displayListe.size() && (verktoyListe.get(tegnet) == 7) && i < maksAntallKanter);
					g.drawPolygon(xpoints,ypoints,i);
					break;
				case 8:
					KnappeBoks.markTegnet=0;
					if (Mark.fortsett==true && tegnet > displayListe.size()-2 && KnappeBoks.antMark > 0){
						p0 = displayListe.get(tegnet++);
						KnappeBoks.antMark--;
						KnappeBoks.jbt8.setText("("+KnappeBoks.antMark+")Mark");
						new Mark(Tegneprogram.this,p0.x,p0.y).start();
					}
					else if (KnappeBoks.antMark == 0 && tegnet > displayListe.size() -2 && sjekker == true){
						int sjekk = JOptionPane.showOptionDialog(null, "Du kan kun ha 10 Mark per tegning. Hvis du bytter tegnerverktoy dreper du markene", "Advarsel", JOptionPane.DEFAULT_OPTION,
								JOptionPane.INFORMATION_MESSAGE, null, null, null);
						if (sjekk == 0 || sjekk == -1){sjekker=false;}
					}
					else{
						tegnet++;
					}
					break;
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Feil ved tegning");
				displayListe = new ArrayList<>();
				fargeListe = new ArrayList<>();
				verktoyListe = new ArrayList<>();
				repaint();
				mainframe.dispose();
				fb.setPath("tmp");
			}
		}
	}

	public void update(Graphics g) {
		paint(g);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == clearBtn) {
			Mark.fortsett = false;
			tegnet = 0;
			KnappeBoks.markTegnet=0;
			KnappeBoks.antMark=10;
			KnappeBoks.jbt8.setText("(" + KnappeBoks.antMark + ")Mark");
			displayListe = new ArrayList<>();
			fargeListe = new ArrayList<>();
			verktoyListe = new ArrayList<>();
			repaint();
		}  else if (e.getSource() == refreshBtn) {

			tegnet = 0;
			repaint();
		}else if (e.getSource() == loadBtn) {
			mainframe.setAlwaysOnTop(false);
			fb.newPath();
			Mark.fortsett=false;
			tegnet = 0;
			fb.loadLists();
			repaint();
		} else if (e.getSource() == quitBtn) {
			setVisible(false);
			System.exit(0);
		}
	}

	//Sjekker for endringer hvert 5. sekund, og evt lagrer
	public void saveTimer(StopWatch sw) throws InterruptedException{
		if(loaded){
			fb.loadLists();
			//Trenger litt tid for å loade listen
			Thread.sleep(500);
			tegnet = 0;
			farge = Color.black;
			repaint();
		}

		while(sw.isStarted()) {
			if (sw.getTime() >= 5000) {
				sw.suspend();
				sw.reset();
				sw.start();
				if (changed) {
					//lager en templiste, så det fungerer å lagre om brukeren tegner mens programmet prøver å lagre
					List<Point> tempListe1 = new ArrayList<>();
					List<Color> tempListe2 = new ArrayList<>();
					List<Integer> tempListe3 = new ArrayList<>();
					tempListe1.addAll(displayListe);
					tempListe2.addAll(fargeListe);
					tempListe3.addAll(verktoyListe);
					fb.tempLists1(tempListe1);
					fb.tempLists2(tempListe2);
					fb.tempLists3(tempListe3);
					fb.saveLists();
					changed = false;
				}

			}
		}
	}

	//Tegner et punkt når bruker klikker en gang
	public void mousePressed(MouseEvent e) {
		changed = true;
		Point p = new Point(e.getX(), e.getY());
		displayListe.add(p);
		fargeListe.add(farge);
		verktoyListe.add(verktoy);
		if (verktoy == 1) {
			verktoyListe.add(verktoy);
			fargeListe.add(farge);
			displayListe.add(p);
		}
		if (verktoy == 7) {
			Mark.fortsett=false;
			tegnet=0;
		}
		if (verktoy!=5 && verktoy!=6) {
			repaint();
		}
	}

	public void mouseReleased(MouseEvent e) {
		if (verktoy == 5 || verktoy == 6) {
			changed = true;
			Point p = new Point(e.getX(), e.getY());
			verktoyListe.add(verktoy);
			fargeListe.add(farge);
			displayListe.add(p);
			repaint();
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		nyMusepeker();
	}

	public void nyMusepeker(){
		Image bilde=null;
		Toolkit verktoykasse = Toolkit.getDefaultToolkit();
		Point punkt = new Point();
		File b=null;
		if (verktoy == 1 || verktoy == 4 || verktoy == 5 || verktoy == 6 || verktoy == 7) {
			bilde = verktoykasse.getImage("penn.png");
			b=new File("penn.png");
			punkt = new Point(0,31);
		}
		if (verktoy == 2){
			bilde = verktoykasse.getImage("viskel.png");
			b=new File("viskel.png");
			punkt = new Point (16,16);
		}
		if (verktoy == 3) {
			bilde = verktoykasse.getImage("malekost.png");
			b = new File("malekost.png");
			punkt = new Point(0, 0);
		}
		if (verktoy == 8){
			bilde = verktoykasse.getImage("mark.png");
			b=new File("mark.png");
			punkt = new Point (0,0);
		}
		if (b.exists() && b != null) {
			Cursor musepeker = verktoykasse.createCustomCursor(bilde, punkt, "musepeker");
			setCursor(musepeker);
		}
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		setCursor(Cursor.getDefaultCursor());
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

}
