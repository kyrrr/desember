package webbydebby.valgdialog;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.List;

import javax.swing.*;

public class SwingSketchDialog implements ListeMedLagredeFiler {
	JDialog jdialog = null;
	private String valgtFile;

	private void setValgtFil(String valgtFile) {
		this.valgtFile = valgtFile;
	}

	@Override
	public String valgListe(List<String> filListe) {
		jdialog = new JDialog();
		JPanel chooserPanel = new JPanel();
		JButton go = new JButton("Velg");
		chooserPanel.setLayout(new BorderLayout());
		chooserPanel.add("North", go);
		String[] fileListArray = new String[filListe.size()];
		filListe.toArray(fileListArray);
		JComboBox<String> jcombobox = new JComboBox<>(fileListArray);
		go.addActionListener(e -> {
            if(valgtFile==null){
                valgtFile= (String)jcombobox.getSelectedItem();
            }
            System.out.println("Valget ditt er " + valgtFile);
            jdialog.setVisible(false);
            //drep jdialog
            jdialog.dispose();
        });
		jcombobox.setEditable(true);
		jdialog.add("North", jcombobox);
		jdialog.add("South", chooserPanel);
		jdialog.setModalityType(JDialog.ModalityType.APPLICATION_MODAL);
		jdialog.pack();
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		jdialog.setLocation(dim.width / 2 - jdialog.getSize().width / 2,
				dim.height / 2 - jdialog.getSize().height / 2);
		jdialog.setVisible(true);
		jcombobox.addActionListener(e -> setValgtFil((String) ((JComboBox) e.getSource()).getSelectedItem()));
		return valgtFile;
	}

}
