package webbydebby.valgdialog;

import java.util.List;

public interface ListeMedLagredeFiler {
	
	/**
	 * Skal returnere en av entriene i listern, eller en helt ny
	 * @param choices
	 * @return
	 */
	String valgListe(List<String> choices);

}
