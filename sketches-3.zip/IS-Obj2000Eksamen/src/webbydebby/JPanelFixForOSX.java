package webbydebby;

import java.awt.Panel;

public class JPanelFixForOSX extends Panel {
//unngår et kjent problem med JPanel for linux og mac osx, der lerettet forsvinner under tegning.
//extends Panel for mac, JPanel for windows
}
